function Init()
    m.settingsList = m.top.findNode("settingsList")
    m.settingsList.setFocus(true)
    LoadSettings()
end function

function LoadSettings()
    registry = CreateObject("roRegistrySection", "Config")
    
    content = CreateObject("roSGNode", "ContentNode")
    
    item = content.createChild("ContentNode")
    item.title = "M3U URL: " + GetSetting(registry, "m3u_url", "Not set")
    
    item = content.createChild("ContentNode")
    item.title = "EPG URL: " + GetSetting(registry, "epg_url", "Not set")
    
    item = content.createChild("ContentNode")
    item.title = "Xtream Server: " + GetSetting(registry, "xtream_server", "Not set")
    
    item = content.createChild("ContentNode")
    item.title = "Sleep Timer: " + GetSetting(registry, "sleep_timer", "Off") + " min"
    
    item = content.createChild("ContentNode")
    item.title = "Sort By: " + GetSetting(registry, "sort_mode", "Name")
    
    item = content.createChild("ContentNode")
    item.title = "Parental Control: " + GetSetting(registry, "parental_enabled", "Off")
    
    item = content.createChild("ContentNode")
    item.title = "Auto-Resume: " + GetSetting(registry, "auto_resume", "On")
    
    m.settingsList.content = content
end function

function GetSetting(registry as object, key as string, default as string) as string
    value = registry.Read(key)
    if value = "" or value = invalid then return default
    return value
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    
    if key = "back"
        m.top.visible = false
        return true
    else if key = "OK"
        EditSetting()
        return true
    end if
    
    return false
end function

function EditSetting()
    selectedIndex = m.settingsList.itemFocused
    if selectedIndex = 0
        ShowKeyboard("Enter M3U URL", "m3u_url")
    else if selectedIndex = 1
        ShowKeyboard("Enter EPG URL", "epg_url")
    end if
end function

function ShowKeyboard(title as string, key as string)
    keyboard = CreateObject("roSGNode", "KeyboardDialog")
    keyboard.title = title
    keyboard.buttons = ["OK", "Cancel"]
    m.top.getParent().dialog = keyboard
    keyboard.observeField("buttonSelected", "onKeyboardButton")
    m.keyToSave = key
end function

function onKeyboardButton(event as object)
    ' Placeholder - full implementation needs dialog handling
end function
