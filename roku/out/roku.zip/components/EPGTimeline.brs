function Init()
    m.epgList = m.top.findNode("epgList")
    m.timeLabel = m.top.findNode("timeLabel")
    
    UpdateTime()
    LoadEPG()
end function

function UpdateTime()
    now = CreateObject("roDateTime")
    m.timeLabel.text = now.asDateString("short-month-no-weekday") + " " + FormatTime(now.asSeconds())
end function

function LoadEPG()
    registry = CreateObject("roRegistrySection", "Config")
    epgUrl = registry.Read("epg_url")
    
    if epgUrl = "" or epgUrl = invalid
        return invalid
    end if
    
    epgData = FetchEPG(epgUrl)
    if epgData = invalid then return invalid
    
    content = CreateObject("roSGNode", "ContentNode")
    
    for each program in epgData.programs
        item = content.createChild("ContentNode")
        item.title = program.title
        item.description = program.description
        item.startTime = program.start
        item.endTime = program.stop
    end for
    
    m.epgList.content = content
end function

function FormatTime(seconds as integer) as string
    hours = (seconds mod 86400) / 3600
    minutes = (seconds mod 3600) / 60
    ampm = "AM"
    if hours >= 12
        ampm = "PM"
        if hours > 12 then hours = hours - 12
    end if
    if hours = 0 then hours = 12
    minStr = stri(minutes).trim()
    if minutes < 10 then minStr = "0" + minStr
    return stri(hours) + ":" + minStr + " " + ampm
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    
    if key = "back"
        m.top.visible = false
        return true
    end if
    
    return false
end function
