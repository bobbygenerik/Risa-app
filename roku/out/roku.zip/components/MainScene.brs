sub Init()
    m.channelGrid = m.top.findNode("channelGrid")
    m.videoPlayer = m.top.findNode("videoPlayer")
    m.statusLabel = m.top.findNode("statusLabel")
    m.errorLabel = m.top.findNode("errorLabel")
    m.heroSection = m.top.findNode("heroSection")
    m.heroTitle = m.top.findNode("heroTitle")
    m.heroChannel = m.top.findNode("heroChannel")
    m.heroTime = m.top.findNode("heroTime")
    m.heroImage = m.top.findNode("heroImage")
    m.heroLogo = m.top.findNode("heroLogo")
    m.heroProgressBar = m.top.findNode("heroProgressBar")
    m.searchOverlay = m.top.findNode("searchOverlay")
    m.searchQuery = m.top.findNode("searchQuery")
    m.searchResults = m.top.findNode("searchResults")
    m.categoryMenu = m.top.findNode("categoryMenu")
    m.categoryList = m.top.findNode("categoryList")

    
    m.channelGrid.observeField("itemSelected", "onChannelSelected")
    m.videoPlayer.observeField("state", "onVideoStateChange")
    m.searchResults.observeField("itemSelected", "onSearchResultSelected")
    m.categoryList.observeField("itemSelected", "onCategorySelected")
    
    m.isPlaying = false
    m.channels = []
    m.allChannels = []
    m.categories = []
    m.currentCategory = "Featured Channels"
    m.favorites = []
    m.currentHeroIndex = 0
    m.searchText = ""
    m.currentView = "main"
    m.heroTimer = invalid
    
    LoadFavorites()
    LoadChannels()
    StartHeroAutoScroll()
end sub

sub LoadFavorites()
    registry = CreateObject("roRegistrySection", "Favorites")
    keys = registry.GetKeyList()
    m.favorites = []
    for each key in keys
        m.favorites.push(key)
    end for
end sub

sub SaveFavorite(channelUrl as string)
    registry = CreateObject("roRegistrySection", "Favorites")
    registry.Write(channelUrl, "1")
    registry.Flush()
    m.favorites.push(channelUrl)
end sub

sub RemoveFavorite(channelUrl as string)
    registry = CreateObject("roRegistrySection", "Favorites")
    registry.Delete(channelUrl)
    registry.Flush()
    for i = 0 to m.favorites.count() - 1
        if m.favorites[i] = channelUrl
            m.favorites.delete(i)
            exit for
        end if
    end for
end sub

function IsFavorite(channelUrl as string) as boolean
    for each fav in m.favorites
        if fav = channelUrl then return true
    end for
    return false
end function

sub StartHeroAutoScroll()
    m.heroTimer = CreateObject("roSGNode", "Timer")
    m.heroTimer.duration = 7
    m.heroTimer.repeat = true
    m.heroTimer.observeField("fire", "onHeroTimerFire")
    m.heroTimer.control = "start"
end sub

sub onHeroTimerFire()
    if m.channels.count() > 0 and m.currentView = "main"
        m.currentHeroIndex = (m.currentHeroIndex + 1) mod m.channels.count()
        UpdateHeroBanner(m.currentHeroIndex)
    end if
end sub

sub LoadChannels()
    m.statusLabel.text = "Loading channels..."
    
    registry = CreateObject("roRegistrySection", "Config")
    m3uUrl = registry.Read("m3u_url")
    if m3uUrl = "" or m3uUrl = invalid
        m3uUrl = "https://iptv-org.github.io/iptv/index.m3u"
    end if
    
    m.loaderTask = CreateObject("roSGNode", "M3ULoaderTask")
    m.loaderTask.url = m3uUrl
    m.loaderTask.observeField("content", "onM3ULoaded")
    m.loaderTask.control = "RUN"
end sub

sub onM3ULoaded()
    content = m.loaderTask.content
    if content = "" or content = invalid
        m.errorLabel.text = "Failed to load playlist"
        m.errorLabel.visible = true
        m.statusLabel.visible = false
        return
    end if
    
    m.allChannels = ParseM3U(content)
    m.channels = m.allChannels
    
    if m.channels.count() > 0
        ExtractCategories()
        DisplayChannels()
    else
        m.errorLabel.text = "No channels found"
        m.errorLabel.visible = true
        m.statusLabel.visible = false
    end if
end sub

function ParseM3U(content as string) as object
    channels = []
    lines = content.split(chr(10))
    
    i = 0
    while i < lines.count()
        line = lines[i].trim()
        
        if line <> "" and left(line, 7) = "#EXTINF"
            channel = ParseExtInf(line)
            
            i = i + 1
            while i < lines.count()
                urlLine = lines[i].trim()
                if urlLine <> "" and left(urlLine, 1) <> "#"
                    channel.url = urlLine
                    channels.push(channel)
                    exit while
                end if
                i = i + 1
            end while
        end if
        
        i = i + 1
    end while
    
    return channels
end function

function ParseExtInf(extinf as string) as object
    channel = {tvgId: "", logo: "", group: "Uncategorized", title: "", url: ""}
    
    tvgIdMatch = ExtractAttribute(extinf, "tvg-id")
    if tvgIdMatch <> "" then channel.tvgId = tvgIdMatch
    
    logoMatch = ExtractAttribute(extinf, "tvg-logo")
    if logoMatch <> "" then channel.logo = logoMatch
    
    groupMatch = ExtractAttribute(extinf, "group-title")
    if groupMatch <> "" then channel.group = groupMatch
    
    commaIndex = instr(1, extinf, ",")
    if commaIndex > 0
        channel.title = mid(extinf, commaIndex + 1).trim()
    else
        channel.title = extinf
    end if
    
    return channel
end function

function ExtractAttribute(line as string, attributeName as string) as string
    searchStr = attributeName + "=" + chr(34)
    startIndex = instr(1, line, searchStr)
    
    if startIndex = 0 then return ""
    
    startIndex = startIndex + len(searchStr) - 1
    endIndex = instr(startIndex, line, chr(34))
    
    if endIndex > 0
        return mid(line, startIndex, endIndex - startIndex)
    end if
    
    return ""
end function

sub ExtractCategories()
    categoryMap = {}
    for each channel in m.allChannels
        if channel.group <> "" and channel.group <> invalid
            categoryMap[channel.group] = true
        end if
    end for
    
    m.categories = ["All Channels", "Favorites"]
    for each cat in categoryMap
        m.categories.push(cat)
    end for
end sub

sub DisplayChannels()
    if m.channels.count() > 0
        UpdateHeroBanner(0)
        m.heroSection.visible = true
    end if
    
    content = CreateObject("roSGNode", "ContentNode")
    
    categoryGroups = {}
    for each channel in m.channels
        cat = channel.group
        if cat = "" or cat = invalid then cat = "Uncategorized"
        if categoryGroups[cat] = invalid then categoryGroups[cat] = []
        categoryGroups[cat].push(channel)
    end for
    
    for each cat in categoryGroups
        row = content.createChild("ContentNode")
        row.title = cat
        
        channels = categoryGroups[cat]
        maxPerRow = 20
        if channels.count() < maxPerRow then maxPerRow = channels.count()
        
        for i = 0 to maxPerRow - 1
            channel = channels[i]
            item = row.createChild("ContentNode")
            item.title = channel.title
            item.url = channel.url
            item.hdPosterUrl = channel.logo
        end for
    end for
    
    m.channelGrid.content = content
    m.channelGrid.visible = true
    m.statusLabel.visible = false
    m.channelGrid.setFocus(true)
    m.currentView = "main"
end sub

sub UpdateHeroBanner(index as integer)
    if index < 0 or index >= m.channels.count() then return
    
    channel = m.channels[index]
    m.heroTitle.text = channel.title
    m.heroChannel.text = channel.group
    m.heroTime.text = "LIVE"
    
    if channel.logo <> "" and channel.logo <> invalid
        m.heroImage.uri = channel.logo
        m.heroLogo.uri = channel.logo
    end if
    
    progress = (index * 100) / m.channels.count()
    m.heroProgressBar.width = 800 * (progress / 100.0)
    
    m.currentHeroIndex = index
end sub

sub onChannelSelected(event as object)
    selection = event.getData()
    if type(selection) = "roArray" and selection.count() >= 2
        rowIndex = selection[0]
        itemIndex = selection[1]
        
        content = m.channelGrid.content
        if content <> invalid and rowIndex >= 0 and rowIndex < content.getChildCount()
            row = content.getChild(rowIndex)
            if row <> invalid and itemIndex >= 0 and itemIndex < row.getChildCount()
                item = row.getChild(itemIndex)
                if item <> invalid and item.url <> invalid
                    for each channel in m.channels
                        if channel.url = item.url
                            PlayChannel(channel)
                            exit for
                        end if
                    end for
                end if
            end if
        end if
    end if
end sub

sub PlayChannel(channel as object)
    m.videoPlayer.visible = true
    m.channelGrid.visible = false
    m.heroSection.visible = false
    m.statusLabel.visible = false
    
    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.url = channel.url
    videoContent.title = channel.title
    videoContent.streamFormat = "hls"
    
    m.videoPlayer.content = videoContent
    m.videoPlayer.control = "play"
    m.videoPlayer.setFocus(true)
    m.isPlaying = true
    m.currentView = "player"
end sub

sub StopPlayback()
    m.videoPlayer.control = "stop"
    m.videoPlayer.visible = false
    m.channelGrid.visible = true
    m.heroSection.visible = true
    m.channelGrid.setFocus(true)
    m.isPlaying = false
    m.currentView = "main"
end sub

sub ShowSearch()
    m.searchOverlay.visible = true
    m.searchText = ""
    m.searchQuery.text = "Type to search..."
    m.searchResults.content = CreateObject("roSGNode", "ContentNode")
    m.searchResults.setFocus(true)
    m.currentView = "search"
end sub

sub HideSearch()
    m.searchOverlay.visible = false
    m.channelGrid.setFocus(true)
    m.currentView = "main"
end sub

sub onSearchResultSelected(event as object)
    HideSearch()
end sub

sub ShowCategories()
    m.categoryMenu.visible = true
    
    content = CreateObject("roSGNode", "ContentNode")
    for each cat in m.categories
        item = content.createChild("ContentNode")
        item.title = cat
    end for
    
    m.categoryList.content = content
    m.categoryList.setFocus(true)
    m.currentView = "categories"
end sub

sub HideCategories()
    m.categoryMenu.visible = false
    m.channelGrid.setFocus(true)
    m.currentView = "main"
end sub

sub onCategorySelected(event as object)
    index = event.getData()
    if index >= 0 and index < m.categories.count()
        selectedCat = m.categories[index]
        m.currentCategory = selectedCat
        
        if selectedCat = "All Channels"
            m.channels = m.allChannels
        else if selectedCat = "Favorites"
            m.channels = []
            for each channel in m.allChannels
                if IsFavorite(channel.url)
                    m.channels.push(channel)
                end if
            end for
        else
            m.channels = []
            for each channel in m.allChannels
                if channel.group = selectedCat
                    m.channels.push(channel)
                end if
            end for
        end if
        
        HideCategories()
        DisplayChannels()
    end if
end sub

sub onVideoStateChange(event as object)
    state = event.getData()
    if state = "error"
        m.errorLabel.text = "Playback error"
        m.errorLabel.visible = true
        StopPlayback()
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    
    if m.currentView = "player"
        if key = "back"
            StopPlayback()
            return true
        end if
    else if m.currentView = "search"
        if key = "back"
            HideSearch()
            return true
        end if
    else if m.currentView = "categories"
        if key = "back"
            HideCategories()
            return true
        end if
    else if m.currentView = "main"
        if key = "options"
            ShowSearch()
            return true
        else if key = "replay"
            ShowCategories()
            return true
        else if key = "info"
            selection = m.channelGrid.itemSelected
            if type(selection) = "roArray" and selection.count() >= 2
                rowIndex = selection[0]
                itemIndex = selection[1]
                content = m.channelGrid.content
                if content <> invalid and rowIndex >= 0 and rowIndex < content.getChildCount()
                    row = content.getChild(rowIndex)
                    if row <> invalid and itemIndex >= 0 and itemIndex < row.getChildCount()
                        item = row.getChild(itemIndex)
                        if item <> invalid and item.url <> invalid
                            if IsFavorite(item.url)
                                RemoveFavorite(item.url)
                            else
                                SaveFavorite(item.url)
                            end if
                        end if
                    end if
                end if
            end if
            return true
        end if
    end if
    
    return false
end function
