function Init()
    m.recentList = m.top.findNode("recentList")
    m.emptyLabel = m.top.findNode("emptyLabel")
    
    LoadRecent()
end function

function LoadRecent()
    history = GetHistory(20)
    
    if history.count() = 0
        m.emptyLabel.visible = true
        return invalid
    end if
    
    content = CreateObject("roSGNode", "ContentNode")
    
    for each item in history
        node = content.createChild("ContentNode")
        node.title = item.title
        node.url = item.url
    end for
    
    m.recentList.content = content
    m.recentList.setFocus(true)
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    
    if key = "back"
        m.top.visible = false
        return true
    end if
    
    return false
end function
